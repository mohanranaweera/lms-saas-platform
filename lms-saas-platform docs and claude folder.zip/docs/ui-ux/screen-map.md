# Screen Map

Status: Draft
Related: `docs/ui-ux/information-architecture.md`, `docs/requirements/source-requirements.md`

## Purpose

Enumerates every concrete screen/page required per portal. Format:

> Portal > Section > Screen name — one-line purpose

Every screen listed here is subject to the baseline requirement (loading, empty,
error, permission-denied where applicable, responsive behavior, accessible form
labels) defined in `frontend/CLAUDE.md` and detailed in `.claude/rules/ui-ux.md`.

---

## Public Storefront (`app/(public)/`)

- Public > Storefront > Tenant Homepage — branded landing page with featured courses/teachers
- Public > Storefront > Course Listing — filterable public catalog of published courses
- Public > Storefront > Course Detail — curriculum, pricing, reviews, FAQ, enroll CTA
- Public > Storefront > Teacher Profile — public teacher bio, assigned public courses
- Public > Storefront > Reviews — approved public reviews list for a course
- Public > Storefront > FAQ — tenant FAQ content

## Authentication (`app/(auth)/`)

A separate route group from the public storefront, per `.claude/rules/frontend.md`'s
"group by role/audience" convention — auth pages need a focused form shell without
storefront/marketing chrome. As shipped in the Application Foundation module, these are
disabled placeholder screens ("Not yet implemented — pending identity-access-service");
real submit behavior lands with that module.

- Public > Auth > Tenant Login — tenant-branded login, resolved by domain/subdomain
- Public > Auth > Student Registration — new student sign-up
- Public > Auth > Forgot Password — password reset request flow

## Student Portal (`app/(student)/`)

- Student > Dashboard > Overview — enrollment/payment summary + expired-access alerts
  (MVP-013). Attendance/exam summary tiles are a future addition once
  `attendance-management`/`exam-management` ship — not present today.
- Student > Courses > My Courses — list of enrolled courses
- Student > Courses > Course Workspace — modules/lessons navigation for one course
- Student > Courses > Lesson/Material View — PDF/notes/image viewer with watermark, expiry/view-limit enforcement
- Student > Courses > Video Player — secure signed-URL playback, watch-time tracking, watermark
- Student > Courses > Catalog / Browse More Courses — authenticated catalog to enroll in additional courses
- Student > Live Classes > Upcoming/Past Live Classes — Zoom join links, recordings
- Student > Attendance > My Attendance — session-by-session attendance history. **Shipped
  (MVP-016)**: `app/(student)/student/attendance/page.tsx`.
- Student > Exams > Exam List — scheduled/available exams
- Student > Exams > Exam Taking — timed exam attempt screen
- Student > Exams > Results & Review — published results, answer review
- Student > Payments > Payment History — all past payments/receipts
- Student > Payments > Outstanding Payments — amounts due, upcoming reminders
- Student > Payments > Payment Slip Upload — manual slip upload form
- Student > Payments > Reactivation — reactivate expired course access
- Student > Devices > My Devices — registered device list, device history
- Student > Reviews > My Reviews — reviews submitted; submit new review (verified-enrollment only)
- Student > Notifications > Notification Center — paginated in-app notification list,
  mark-as-read, unread-count nav badge. **Shipped (MVP-018)**:
  `app/(student)/student/notifications/page.tsx`.
- Student > Notifications > Notification Preferences — per-channel notification preference
  center. **Not shipped** — Phase 2 (`functional-requirements.md` FR-NM-2..5); this line was
  previously bundled with the Notification Center entry above as if both had shipped
  together, which was inaccurate once MVP-018 shipped only the Center.
- Student > Support > My Tickets — ticket list, ticket detail, new ticket
- Student > Profile > Profile & Guardian Info — student profile, guardian/parent fields, school/grade/stream

## Teacher Portal (`app/(teacher)/`)

- Teacher > Dashboard > Overview — assigned-course statistics (total/published/draft counts)
  and a recent-courses list, all from the teacher-ownership-scoped `GET /api/v1/courses` read
  (MVP-014, shipped). Pending-marking and upcoming-classes tiles named in the original backlog
  entry are **not** part of the shipped Overview — no `attendance-management`/`exam-management`/
  `live-class-management` backend domain exists yet to supply that data; adding those tiles is
  that future domain's own module scope, not a retrofit on MVP-014 (mirrors the identical
  Student Overview correction above).
- Teacher > Courses > My Courses — assigned courses list
- Teacher > Courses > Course Builder — create/edit course metadata, pricing, enrollment rules, access duration, visibility, prerequisites
- Teacher > Courses > Module & Lesson Editor — course modules/lessons structure
- Teacher > Courses > Materials Manager — upload/organize PDFs, images, videos, recordings; drag-and-drop ordering; visibility/expiry/limits/watermark settings
- Teacher > Courses > Landing Page & SEO — course landing page builder, SEO fields
- Teacher > Courses > Course Reviews — view/respond to reviews
- Teacher > Roster > Course Roster — students enrolled in an assigned course
- Teacher > Live Classes > Schedule Live Class — create Zoom session
- Teacher > Live Classes > Recordings — manage/attach recordings to lessons
- Teacher > Attendance > Mark Attendance — manual attendance marking per session. **Shipped
  (MVP-016)**: `app/(teacher)/teacher/attendance/mark/page.tsx`.
- Teacher > Attendance > Attendance Reports — per-course/teacher attendance report. **Shipped
  (MVP-016)**: `app/(teacher)/teacher/attendance/reports/page.tsx`.
- Teacher > Exams > Question Bank — MCQ/structured question management (shipped, MVP-017)
- Teacher > Exams > Exam Scheduler — create/schedule exams, time limits (shipped, MVP-017; attempt limits are Phase 2, not built)
- Teacher > Exams > Marking Queue — manual marking of structured answers (shipped, MVP-017)
- Teacher > Exams > Results Publishing — publish results (shipped, MVP-017; rank lists are Phase 2, not built — FR-EX-4)
- Teacher > Reports > My Performance — teacher performance analytics
- Teacher > Notifications > Activity Feed — same underlying list/mark-read/unread-count
  component as the Student Notification Center, server-filtered to the Teacher's own
  notifications under a Teacher-scoped route. Genuinely empty at launch (no
  Teacher-triggering event exists in MVP-018's wiring — all three trigger events are
  payment outcomes, which only reach Student recipients). **Shipped (MVP-018)**:
  `app/(teacher)/teacher/notifications/page.tsx`. This line did not previously exist
  anywhere in this file — a genuine IA gap found during MVP-018's post-ship review, not a
  pre-existing entry that was merely updated.
- Teacher > Support > My Tickets — teacher support tickets
- Teacher > Profile > Profile & Availability — teacher profile, availability, payout profile

## Tenant Admin Portal (`app/(tenant-admin)/`)

- Tenant Admin > Dashboard > Overview — Students/Courses (published+draft)/Payments-recorded-count
  KPI tiles, all from three already-tenant-scoped reads (MVP-015, shipped). A ledger-derived
  currency/revenue total and a tenant-profile (TEN-1) KPI tile are **not** part of the shipped
  Overview — no revenue-summary or tenant-profile read endpoint exists yet
  (`docs/requirements/open-decisions.md` §19). Alerts named in the original backlog entry are
  also not shipped — no alerting domain exists yet.
- Tenant Admin > Students > Student List — search/filter/manage students
- Tenant Admin > Students > Student Detail — profile, enrollment/payment/attendance/exam/device/communication history, timeline
- Tenant Admin > Students > Bulk Import — CSV/bulk student creation
- Tenant Admin > Teachers > Teacher List — teacher management
- Tenant Admin > Teachers > Teacher Detail — profile, approval, assigned courses, commission settings
- Tenant Admin > Staff > Staff List — staff accounts, status
- Tenant Admin > Staff > Staff Detail / Role Editor — role-based permission assignment
- Tenant Admin > Staff > Activity Log — staff activity log
- Tenant Admin > Courses > Course List — all tenant courses, status, category
- Tenant Admin > Courses > Course Detail / Approval — oversight of teacher-authored courses
- Tenant Admin > Materials > Materials Oversight — folder structure, bulk upload management
- Tenant Admin > Live Classes > Zoom Accounts — tenant Zoom account integration, multiple accounts
- Tenant Admin > Live Classes > Live Class Oversight — scheduled/past sessions across teachers
- Tenant Admin > Attendance > Attendance Reports — student/course/teacher-level reports.
  **Shipped (MVP-016)**: `app/(tenant-admin)/tenant-admin/attendance/reports/page.tsx` (Tenant
  Admin, Attendance Operator, Read-only Auditor — gated by `canViewAttendanceReports`).
- Tenant Admin > Attendance > Mark Attendance — tenant-wide manual attendance marking (Attendance
  Operator/Tenant Admin only, no course-ownership restriction). **Shipped (MVP-016)**:
  `app/(tenant-admin)/tenant-admin/attendance/mark/page.tsx` (gated by `canMarkAttendanceStaff`).
  Not part of the original screen catalog entry above — added because the permission matrix
  already grants Attendance Operator `CREATE_EDIT`, so a marking surface for that role must exist
  somewhere (plan §11's own reasoning).
- Tenant Admin > Exams > Exam Oversight — exam list across courses (shipped, MVP-017)
- Tenant Admin > Exams > Model Paper Library — shared paper library (**Phase 3, not part of the MVP-017 build** — `docs/plans/MVP-017 Exams.md` §6 explicitly excludes it; this line predates that scoping decision)
- Tenant Admin > Payments > Payment Dashboard — all payments, statuses
- Tenant Admin > Payments > Manual Slip Review Queue — pending slip approvals
- Tenant Admin > Payments > Slip Detail / Duplicate & Suspicious Flags — OCR reference, duplicate check results, override with reason (audit-logged)
- Tenant Admin > Payments > Refunds — refund issuance
- Tenant Admin > Payments > Payment Reports — exportable reports
- Tenant Admin > Finance > Income Dashboard — income overview
- Tenant Admin > Finance > Expense Dashboard — category/account-wise expenses
- Tenant Admin > Finance > Accounts — bank/cash account management
- Tenant Admin > Finance > Tutor Payouts — payout tracking (phase 2)
- Tenant Admin > Finance > Financial Reports — profit/loss, cashflow, exports
- Tenant Admin > Communications > Templates — email/SMS/WhatsApp template editor
- Tenant Admin > Communications > Bulk Messaging — segment messaging composer
- Tenant Admin > Communications > Delivery Logs — sent/failed message log
- Tenant Admin > Integrations > Integration Settings — Zoom/SMS/WhatsApp/email/payment gateway/storage config
- Tenant Admin > Integrations > Webhook & Health Logs — integration health checks
- Tenant Admin > Devices > Device Policy — tenant/course-level device limit overrides
- Tenant Admin > Devices > Device Reset & History — reset device, view login activity, suspicious login flags
- Tenant Admin > Access & Expiry > Expiry Rules — rules engine, grace periods
- Tenant Admin > Access & Expiry > Reactivation Approvals — approve reactivation requests
- Tenant Admin > Reviews > Moderation Queue — approve/reject reviews
- Tenant Admin > Reports > Reports & Analytics — cross-module tenant reports
- Tenant Admin > Audit Log > Audit Log Viewer — tenant-scoped, read-only, immutable log
- Tenant Admin > Support > Ticket Queue — ticket list, assignment, internal notes
- Tenant Admin > Support > Ticket Detail — related payment/course/student links
- Tenant Admin > Branding > Branding Settings — logo, colors, favicon, custom domain, templates, certificate/invoice branding
- Tenant Admin > Branding > Branding Preview Panel — live preview through production theming pipeline
- Tenant Admin > Settings > Tenant Profile & Subscription — plan, feature limits, usage tracking

## Platform Admin Portal (`app/(platform-admin)/`)

- Platform Admin > Dashboard > Overview — platform-wide KPIs. **Not shipped** — still the
  original static placeholder (MVP-001); MVP-020 updated only its copy (it previously claimed
  Tenants/Payments/Audit Log were themselves unshipped, which became false once MVP-020 landed
  them) and added links to the three live screens below. No KPI/summary data-fetching exists.
- Platform Admin > Tenants > Tenant List — all tenants, status, plan. **Shipped (MVP-020,
  PADASH-1)**: `app/(platform-admin)/platform-admin/(dashboard)/tenants/page.tsx`.
- Platform Admin > Tenants > Tenant Approval — review/approve/reject new tenant registration.
  **Shipped (MVP-020, PADASH-1)** — not a separate screen; Approve/Reject actions live inline on
  the Tenant List row and the Tenant Detail screen (both `AlertDialog`-confirmed).
- Platform Admin > Tenants > Tenant Detail — profile, plan, usage, status control
  (suspend/cancel/reactivate). **Partially shipped (MVP-020, PADASH-1)**:
  `.../tenants/[tenantId]/page.tsx` — profile/plan/contact summary + Approve/Reject only.
  Suspend/cancel/reactivate and any usage data are explicitly out of scope (module plan §6/§21
  item 1) — do not assume this screen's status control is complete.
- Platform Admin > Plans > Plan & Feature Flag Editor — plan limits, feature toggles. Not
  shipped.
- Platform Admin > Payments > Cross-Tenant Payment Dashboard — platform-wide payment oversight.
  **Shipped (MVP-020, PADASH-2)**: `.../payments/page.tsx` (list) +
  `.../payments/[tenantId]/page.tsx` (per-tenant drill-down, persistent tenant-context banner).
  Read-only — no refund/adjustment action reachable from here (module plan §17).
- Platform Admin > Payments > Settlement Runs — tutor/tenant settlement calculation, status,
  export. Not shipped — Phase 2 (payment roadmap step 2, root `CLAUDE.md`).
- Platform Admin > Finance > Platform Finance Reports — platform-level financial reporting. Not
  shipped.
- Platform Admin > Integrations > Platform Default Integrations — default
  Zoom/SMS/WhatsApp/email/gateway/storage config. Not shipped.
- Platform Admin > Integrations > Credential Vault — API credential management. Not shipped.
- Platform Admin > Reports > Platform Analytics — churn risk, most-watched courses,
  bandwidth/storage usage, device violations, ticket volume. Not shipped.
- Platform Admin > Audit Log > Platform Audit Log — platform-scope actions. **Shipped (MVP-020,
  PADASH-2)**: `.../audit-log/page.tsx`.
- Platform Admin > Audit Log > Tenant Audit Log Drill-down — per-tenant audit log,
  tenant-context banner required. **Shipped (MVP-020, PADASH-2)**: `.../audit-log/[tenantId]/page.tsx`.
- Platform Admin > Support > Cross-Tenant Ticket Queue — escalated/all-tenant tickets. Not
  shipped.
- Platform Admin > Impersonation > Start/End Impersonation — enter/exit "view as tenant" mode.
  Not shipped — MVP-020 is read-only/non-impersonating by design (module plan §21, risk R9/R15).

## Shared / Cross-Role Screens (implemented once, reused per role's route group)

- Shared > Auth > Login (role-specific entry, tenant-resolved branding)
- Shared > Auth > Forgot/Reset Password
- Shared > Notifications > Notification Preferences
- Shared > Error > 403 Permission-Denied Page
- Shared > Error > 404 Not Found
- Shared > Error > 500 / Unexpected Error

## Open questions

- Whether "Model Paper Library" and "Rank Lists" are Teacher-only, Tenant-Admin-only,
  or both is not resolved by source requirements — flagging for product decision.
- Mobile app screens (module 5/phase 3, "Mobile apps") are out of scope for this
  web IA and screen map; a separate mobile IA would be needed if pursued.
