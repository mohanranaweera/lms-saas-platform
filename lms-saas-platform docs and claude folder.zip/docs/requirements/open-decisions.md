# Open Decisions

This is the consolidated tracking log for every unresolved business/product decision surfaced
while building the feature specifications under `docs/requirements/specifications/` (produced by
a five-agent review of `docs/requirements/`, `docs/architecture/`, and `docs/ui-ux/` in
2026-08). Nothing here was invented — each item is either an explicit open question already
flagged in the source documents, or a gap identified by cross-checking documents against each
other during that review. Items are grouped by category; each cites the affected feature(s) and
source.

**How to use this log**: when an item below is resolved, update the relevant spec file(s) under
`docs/requirements/specifications/` and either remove the entry here or mark it resolved with a
date and a pointer to the decision record (an ADR, if the item touches a change-controlled area).

---

## 1. Registration / access model

- **Tenant self-registration**: whether the initial institute-registration entry point is
  public/self-serve or invite-only (Platform Admin outreach) is unresolved.
  Affects: [01-tenant-onboarding.md](specifications/01-tenant-onboarding.md).
  Source: `docs/ui-ux/user-journeys.md` line 205-207; `docs/requirements/user-roles-and-permissions.md` Open Q4.
- **Student self-registration**: same public-vs-invite-only question, unresolved.
  Affects: [03-student-management.md](specifications/03-student-management.md).
  Source: `docs/requirements/user-roles-and-permissions.md` §1, Open Q4; `docs/ui-ux/user-journeys.md` Journey 4.
- **Teacher registration mechanism**: self-register-then-approve vs. Tenant-Admin-invited-only is not specified.
  Affects: [04-teacher-management.md](specifications/04-teacher-management.md).
- No rejection-reason/notification workflow, duplicate-registration handling, or re-application flow is specified for tenant onboarding.
- Uniqueness scope for tenant subdomain/custom domain is implied but never explicitly stated as a constraint.

## 2. Permission-matrix gaps (no row, or an ambiguous row, in `docs/requirements/user-roles-and-permissions.md` §2)

- **Notifications/Communications**: no dedicated permission-matrix row exists for templates, bulk/segment messaging, or delivery logs. Which staff sub-role(s) may perform these actions is unspecified.
  Affects: [12-notifications.md](specifications/12-notifications.md), [21-sms.md](specifications/21-sms.md), [22-whatsapp.md](specifications/22-whatsapp.md).
- **Zoom scheduling**: no explicit row covers "who may schedule a Zoom session / manage recordings."
  Affects: [19-zoom-live-classes.md](specifications/19-zoom-live-classes.md).
- **Settlement-run triggering**: exact split of who can trigger a run (Platform Admin only vs. tenant-level Finance Staff/Institute Owner) is not fully specified.
  Affects: [24-settlements.md](specifications/24-settlements.md).
- **Expense approval**: the matrix gives Finance Staff/Institute Owner plain `V/C/E/D` on Finance & Expenses with no distinct `A` (approve) column, unlike Payments/Courses/Exams — a gap if the recommended expense-approval workflow is built.
  Affects: [23-finance-and-expenses.md](specifications/23-finance-and-expenses.md).
- **Teacher approval** — **RESOLVED 2026-08-13.** No explicit `A` (approve) column exists for
  Course Coordinator on "Teachers," unlike Courses/Payments/Exams which do have one. Confirmed:
  Tenant Admin only. Implemented as a service-layer defense-in-depth role check
  (`TeacherService.requireTenantAdmin()`, checking `AuthenticatedPrincipalHolder.get().role()`
  literally equals `"TENANT_ADMIN"`) layered on top of the existing shared `TEACHERS`/
  `CREATE_EDIT` grant, which Course Coordinator also holds for teacher *creation*. The shipped
  `PermissionCheckServiceImpl` matrix itself is unchanged — no new `TEACHERS`/`APPROVE` grant was
  added — mirroring the same defense-in-depth pattern already applied to `StaffService`
  (commit `d265597`). Course Coordinator can create teacher accounts but is rejected `403` on
  approve/reject, verified end-to-end in `TeacherManagementIntegrationTest`
  (`courseCoordinatorCanCreateButCannotApproveOrRejectTeachers`) and unit-tested in
  `TeacherServiceTest`. See `docs/plans/MVP-007 Teacher Management.md` §2/§21 item 1 for the two
  options that were weighed before this was confirmed.
  Affects: [04-teacher-management.md](specifications/04-teacher-management.md).
- **Custom-domain approval**: whether Platform Admin must approve/verify a tenant's custom domain is not addressed.
  Affects: [15-custom-domains.md](specifications/15-custom-domains.md).
- **Staff sub-role "own-area" audit scoping — interim resolution shipped in MVP-019, "own area" itself still undefined.** No document defines what counts as a sub-role's "own area," so MVP-019's `AuditLogQueryService` does not attempt to enforce it. Instead, the viewer (`GET /api/v1/audit-log`) is restricted, on top of the existing coarse `AUDIT_LOG`/`VIEW` grant, to an explicit allowlist of `TENANT_ADMIN`/`READ_ONLY_AUDITOR` only (plan §21 decision 1, option B) — every other staff sub-role that already holds the grant (Finance Staff, Course Coordinator, Content Manager, etc.) is denied `403` by this endpoint until a real "own-area" mechanism is defined, rather than being shipped with full tenant-wide visibility. See `docs/api/audit-log-management.md`'s "Authorization model" section.
  Affects: [13-audit-logs.md](specifications/13-audit-logs.md).
  Source: `docs/plans/MVP-019 Audit Logs.md` §21 item 1.
- **Payment-gateway webhook actor gap — declined for MVP-019, tracked as open.** `PaymentConfirmedEvent`/`PaymentRejectedEvent` (webhook-driven gateway confirm/reject) have no real, authenticated `tenant_user` actor, and `audit_log.actor_id` is a `NOT NULL` FK to `tenant_user` — MVP-019 deliberately does not wire a listener for either event rather than inventing a synthetic actor or relaxing the FK. This means `PAY-2` (gateway confirm/reject) has no audit trail, a real gap against `.claude/rules/security.md`'s canonical mandatory-audit list. Live options if a future module wants this closed: (a) a reserved per-tenant "system" `tenant_user` row as a well-known FK target (requires its own migration/seeding design), or (b) make `actor_id` nullable with a documented "null = system/automated" convention (reverses a schema-enforced invariant in `.claude/rules/backend.md`) — neither is decided here.
  Affects: [13-audit-logs.md](specifications/13-audit-logs.md).
  Source: `docs/plans/MVP-019 Audit Logs.md` §21 item 2.

## 3. Provisional / unratified roles

- **Teacher Assistant's entire permission boundary is PROVISIONAL, unratified.** `docs/requirements/user-roles-and-permissions.md` §3 states explicitly: "No source document defines Teacher Assistant's permission boundary today... do not build a hard permission gate against it without sign-off." This is a reasonable default, not a confirmed decision.
  Affects: [04-teacher-management.md](specifications/04-teacher-management.md), [05-course-management.md](specifications/05-course-management.md), [06-lessons-and-materials.md](specifications/06-lessons-and-materials.md), [10-attendance.md](specifications/10-attendance.md), [11-exams.md](specifications/11-exams.md), [26-course-reviews.md](specifications/26-course-reviews.md).

## 4. Approval-precedence ambiguity

- **Reactivation approver**: whether Finance Staff or Institute Owner (or both, with what precedence) is the correct approver for reactivation requests, and manual payment slip approval generally, when both are eligible.
  Affects: [08-manual-payment-slips.md](specifications/08-manual-payment-slips.md), [09-enrollments.md](specifications/09-enrollments.md), [18-smart-expiry.md](specifications/18-smart-expiry.md).
  Source: `docs/requirements/user-roles-and-permissions.md` Open Q2.
- **Course-approval second approver**: whether Course Coordinator's course-approval authority (`A`) requires a second approver for high-value/published courses.
  Affects: [05-course-management.md](specifications/05-course-management.md).
  Source: `docs/requirements/user-roles-and-permissions.md` Open Q3.

## 5. Audit-logging gaps and inconsistencies

- **Exam-result publication audit gap (documentation inconsistency)**: `functional-requirements.md` FR-EX-2 states result publication is "a confirmable, audit-considered action," but exam-result publication is **not** in `.claude/rules/security.md`'s canonical mandatory-audit-action list (price changes, payment approvals/rejections, device resets, access/expiry extensions, reactivation approvals, material/course content deletions, settlement amount changes, impersonation). This should be settled explicitly — either extend the security-rule list or soften FR-EX-2's language.
  Affects: [11-exams.md](specifications/11-exams.md), [13-audit-logs.md](specifications/13-audit-logs.md).
- **Staff account creation/role changes**: whether these require an audit-log entry is unspecified, despite the high blast-radius of role assignment.
  Affects: [02-staff-management.md](specifications/02-staff-management.md).
- **Student status changes / Student Support edits**: whether these require an audit-log entry is unspecified.
  Affects: [03-student-management.md](specifications/03-student-management.md).
- **Teacher approval**: whether it requires an audit-log entry is unspecified (unlike tenant approval, which explicitly does).
  Affects: [04-teacher-management.md](specifications/04-teacher-management.md).
- **Tenant onboarding approval/status-change**: audit-logging is required per `functional-requirements.md`/`user-journeys.md`, but this action is **not** itself named in `.claude/rules/security.md`'s canonical list — a gap between the two documents' scope, not a missing requirement.
  Affects: [01-tenant-onboarding.md](specifications/01-tenant-onboarding.md).
- **Branding/theme changes**: whether these require an audit-log entry is unresolved.
  Affects: [14-white-labelling.md](specifications/14-white-labelling.md).
- **Custom-domain enable/disable or DNS/TLS config changes**: whether audit-logged is unresolved.
  Affects: [15-custom-domains.md](specifications/15-custom-domains.md).
- **Zoom link-sharing enforcement failures / recording-attach actions**: whether these require a dedicated audit entry is unresolved.
  Affects: [19-zoom-live-classes.md](specifications/19-zoom-live-classes.md).
- **Bulk-messaging actions (SMS/WhatsApp)**: whether these need an audit entry distinct from delivery logs is unresolved.
  Affects: [21-sms.md](specifications/21-sms.md), [22-whatsapp.md](specifications/22-whatsapp.md).
- **Expense record deletion**: the permission matrix grants Finance Staff/Institute Owner literal `D` (hard delete) on Finance & Expenses, which is in tension with `non-functional-requirements.md` §9's "financial history... is never deleted" principle and the append-only pattern used elsewhere in the payment/ledger cluster. Whether this is an intentional exception or an inconsistency to fix is unresolved — **flagging, not resolving unilaterally.**
  Affects: [23-finance-and-expenses.md](specifications/23-finance-and-expenses.md).
- **Course review moderation actions**: whether approve/reject requires an audit entry is unresolved.
  Affects: [26-course-reviews.md](specifications/26-course-reviews.md).
- **Audit-log retention/purge policy**: no policy exists beyond "retained indefinitely by default; a future retention/purge policy is a separate approved process."
  Affects: [13-audit-logs.md](specifications/13-audit-logs.md).
  Source: `docs/requirements/non-functional-requirements.md` §9, Open Q5.

## 6. Domain-ownership gaps (unratified per `docs/requirements/module-catalog.md`)

- **Public Storefront (Module C)**, **Feature Flag & Plan Limit Engine (Module D)**, and **AI
  Assistant (Module F)** are explicitly unowned/unratified cross-cutting items per
  `module-catalog.md`'s "Cross-Cutting / Unowned Items" section. Module D specifically is called
  "needed from day one" in source requirements yet has no owning domain — it gates plan-based
  entitlements referenced throughout this catalog. See
  [portals-overview.md](portals-overview.md) "Cross-cutting / not yet owned by a portal."
  Affects (directly depend on Module D): [02-staff-management.md](specifications/02-staff-management.md) (FR-UM-9 staff-count limit), [14-white-labelling.md](specifications/14-white-labelling.md), [15-custom-domains.md](specifications/15-custom-domains.md) (plan entitlement gating).
- **Course-reviews moderation-workflow ownership**: whether `course-management` or a not-yet-named domain (possibly `support-management`) owns the review submission/moderation *workflow*, versus just the course-level toggle.
  Affects: [26-course-reviews.md](specifications/26-course-reviews.md).
  Source: `module-catalog.md` Open Question #1.
- **`finance-expense-management` vs. `ledger-settlement-management` domain-count question**: whether these should remain two domains, or whether the tutor-payout linkage is thin enough to fold into one. Flagged only as a documentation question in `module-catalog.md`, not a proposal to merge — current default (two domains) stands unless changed via the confirmed-domain-list process.
  Affects: [23-finance-and-expenses.md](specifications/23-finance-and-expenses.md), [24-settlements.md](specifications/24-settlements.md).
  Source: `module-catalog.md` Open Question #2.
- **Attendance-based access restrictions ↔ enrollment expiry boundary**: "attendance-based access restrictions" (Phase 2) is owned entirely by `attendance-management` per `module-catalog.md`, but restricting course/material *access* is architecturally `enrollment-management`'s concern. No document resolves which domain enforces the restriction. This is a new gap identified during this review, analogous to the Module C/D/F gaps.
  Affects: [10-attendance.md](specifications/10-attendance.md), [09-enrollments.md](specifications/09-enrollments.md).
- **Model Paper Library ownership**: between Teacher and Tenant Admin, unresolved.
  Affects: [11-exams.md](specifications/11-exams.md).
  Source: FR-EX-5; `docs/ui-ux/screen-map.md` line 150-151.

## 7. Payment/ledger business decisions (explicitly deferred, not invented — per `docs/architecture/payment-ledger.md` §10)

- Which specific payment gateway will be integrated, and what payment methods it supports.
- Refund window/eligibility policy.
- Exact commission percentage(s), and whether commission varies by tenant plan/tier.
- Exact gateway-fee handling (pass-through deduction vs. platform-absorbed; variance by payment method).
- Settlement run cadence (weekly/monthly/on-demand) and exact "settlement period" boundary definition.

Affects: [07-orders-and-payments.md](specifications/07-orders-and-payments.md),
[24-settlements.md](specifications/24-settlements.md).

## 8. Enrollment / expiry business decisions (per `docs/architecture/enrollment-access.md` §9)

- Exact grace period length(s) — no default specified.
- Exact expiry-rules-engine precedence order — **explicitly not assumed** to mirror the device-limit precedence pattern (student > course > tenant > plan) without a separate confirming decision.
- Whether reactivation always requires a full new payment or a prorated/partial payment is ever allowed.
- Whether bulk expiry extension requires a second-approver step beyond the acting admin's normal permission.
- Exact reminder timing before expiry.

Affects: [18-smart-expiry.md](specifications/18-smart-expiry.md).

(See §18 below for MVP-012's implementation status against this section's items — course-level
expiry and the reactivation core have since shipped; the items above remain open exactly as
listed here, none were silently narrowed or assumed.)

## 9. Third-party provider selection (none named anywhere — do not invent a vendor)

- SMS provider — not selected.
- WhatsApp Business API provider — not selected.
- External video/object storage provider (for secure video) — not selected; evaluation criteria are recorded in `docs/adr/ADR-008-video-content-protection-mechanism.md` §2.
- OCR provider/mechanism for Phase 3 payment-slip intelligence — not named anywhere.

Affects: [21-sms.md](specifications/21-sms.md), [22-whatsapp.md](specifications/22-whatsapp.md),
[20-secure-video.md](specifications/20-secure-video.md),
[25-duplicate-payment-slip-detection.md](specifications/25-duplicate-payment-slip-detection.md).

## 10. Technical mechanism gaps not covered by an ADR

- **Custom-domain DNS/TLS provisioning**: no provider or automation approach is decided.
  Affects: [15-custom-domains.md](specifications/15-custom-domains.md).
  Source: `docs/architecture/deployment-architecture.md` §6.
- **Zoom link-sharing prevention mechanism**: the requirement exists (FR-LCM-2) but the concrete enforcement mechanism is not specified.
  Affects: [19-zoom-live-classes.md](specifications/19-zoom-live-classes.md).
- **Whether Zoom join-link protection follows the same signed-URL/short-lived-token rule as video**: `.claude/rules/security.md`'s "Video & Session Protection" section only names video explicitly.
  Affects: [19-zoom-live-classes.md](specifications/19-zoom-live-classes.md).
- **WhatsApp template-approval state machine and opt-in/consent handling**: not addressed in any source document.
  Affects: [22-whatsapp.md](specifications/22-whatsapp.md).
- **Whether YouTube/Vimeo-attached content is subject to the same view-limit/expiry/watermark/device-restriction controls as platform-hosted secure video, or exempt.** A raw YouTube/Vimeo embed URL is inherently more guessable/shareable than a signed platform token, and no document resolves the seam.
  Affects: [27-youtube-vimeo-integrations.md](specifications/27-youtube-vimeo-integrations.md).
- **Monthly-closing lock semantics** for Finance & Expenses (mutation-after-close behavior).
  Affects: [23-finance-and-expenses.md](specifications/23-finance-and-expenses.md).
- **Zoom-sync participant-name reconciliation rule**: no rule specified for when Zoom-sync attendance data doesn't match an enrolled student's standardized name.
  Affects: [10-attendance.md](specifications/10-attendance.md).
- **Bulk-import partial-failure behavior** (students, and by extension any future bulk-import flow): all-or-nothing vs. row-level partial success with an error report is not specified.
  Affects: [03-student-management.md](specifications/03-student-management.md).
- **No concrete visibility taxonomy** is defined for material visibility (what values it can take).
  Affects: [06-lessons-and-materials.md](specifications/06-lessons-and-materials.md).
- **The seam between `content-management`'s expiry/limits and `video-access-management`'s full playback-security stack** for "a video attached as a lesson material" is not spelled out.
  Affects: [06-lessons-and-materials.md](specifications/06-lessons-and-materials.md).

## 11. Documentation inconsistencies to reconcile (not open decisions, but contradictions between source docs)

- **Zoom-recording-attachment phase contradiction**: `source-requirements.md` module 7 implies MVP scope includes attaching Zoom recordings to lessons, but `live-class-management` (which owns Zoom recording management) is entirely Phase 2 per `functional-requirements.md`/`module-catalog.md`. "Attach a Zoom recording to a lesson" cannot actually be delivered at MVP.
  Affects: [06-lessons-and-materials.md](specifications/06-lessons-and-materials.md).
- **Duplicate-slip-detection OCR timing narrative mismatch**: `docs/ui-ux/user-journeys.md` Journey 3 describes OCR reference extraction as already running in the near-term staff review flow, while `functional-requirements.md` FR-PM-3 explicitly phases OCR-based detection to Phase 3 (only exact-match checks are MVP). The FR table should be treated as authoritative, but this should be verified with the requirements owner rather than assumed.
  Affects: [25-duplicate-payment-slip-detection.md](specifications/25-duplicate-payment-slip-detection.md).
- **"Checkout" screen naming gap**: `docs/ui-ux/user-journeys.md` Journey 1 references a `Student > Payments > Checkout` screen that is not actually enumerated in `docs/ui-ux/screen-map.md`'s Student Portal screen list.
  Affects: [07-orders-and-payments.md](specifications/07-orders-and-payments.md).

## 12. WordPress migration — needs a full requirements pass, not a single open decision

Unlike every other item in this log, WordPress migration has **zero presence** in
`docs/requirements/`, `docs/architecture/`, or `docs/ui-ux/` — it exists only as an internal
engineering skill/agent definition (`.claude/skills/wordpress-migration/SKILL.md`,
`.claude/agents/legacy-migration-engineer.md`). See
[28-wordpress-migration.md](specifications/28-wordpress-migration.md) for what little is defined.
Recommend a dedicated requirements pass (business purpose, actor, scope, target-domain mapping,
phase) before treating it as a scoped feature, plus a dedicated ADR before any implementation
given it would populate change-controlled ledger/enrollment tables.

## 13. UI/UX documentation gaps (component-library and journey coverage)

- **Status Chip vocabulary** (`docs/ui-ux/component-library-spec.md` §2.10) has no entries for: device status (Active/Reset-Pending/Blocked), SMS/WhatsApp delivery status, WhatsApp template-approval status, or settlement-run status.
- **No documented UX journey exists for**: settlement runs, YouTube/Vimeo attach failures, custom-domain verification, or session-view-limit/concurrent-session-blocked states — these need journey-level documentation analogous to `docs/ui-ux/user-journeys.md` Journeys 1-6 before implementation.
- **Star-rating accessible input pattern** (course reviews) and **embedded third-party video player accessibility** (YouTube/Vimeo) are both gaps not covered in `docs/ui-ux/accessibility.md`.
- **Watermark overlay contrast/positioning** has no accessibility guidance for secure video.

## 14. Approval status of drafted ADRs

All three mechanism-level ADRs referenced throughout this catalog are **Accepted (2026-08-02)**:
`docs/adr/ADR-006-tenant-isolation-repository-mechanism.md`,
`docs/adr/ADR-007-authentication-token-and-device-mechanism.md`, and
`docs/adr/ADR-008-video-content-protection-mechanism.md`. Implementation may proceed against all
three domains' decisions — including
[17-session-view-limits.md](specifications/17-session-view-limits.md) and
[20-secure-video.md](specifications/20-secure-video.md) — without a further ADR-approval
prerequisite.

## 15. Student Management (MVP-006) — items surfaced during module planning/implementation

Surfaced by `docs/plans/MVP-006 Student Management.md` §21, not by the original five-agent
requirements review that produced sections 1–14 above — logged here per that plan's own §19
instruction. Only the items not already tracked elsewhere in this log at this level of detail
are listed (the plan's own self-registration public-vs-invite-only question is already covered
in §1 above; the bulk-import partial-row-failure question is already covered in §10 above).

- **Guardian/parent info and school/grade/stream field list is not itemized anywhere.** STU-1's
  own backlog entry proposes a concrete-looking schema sketch
  (`guardian_name, guardian_contact, school, grade, stream`), but this is an unratified
  placeholder, not a confirmed column list — the tension between the explicit "not itemized"
  note and the concrete-looking sketch should be resolved explicitly, not silently treated as
  final. Not one of the original 9 items plan §19 instructed appending here (it's already
  present in the spec's own Open Decisions list, `03-student-management.md`), but added as its
  own bullet regardless so `docs/architecture/database-architecture.md`'s cross-reference to
  this section for `student_profile`'s still-provisional column set points at something that
  actually exists here.
  Affects: [03-student-management.md](specifications/03-student-management.md).
  Source: `docs/plans/MVP-006 Student Management.md` §8.1 (provisional column list), §21 item 3.
- **`student_profile.status` column — recommended deviation from the backlog's literal text,
  needs explicit confirmation.** STU-1's own database-impact line in `product-backlog.md` lists
  `status` as a `student_profile` column, but the shipped migration deliberately omits it,
  reusing `tenant_user.status` instead — matching the `staff_profile`/STAFF-1 precedent and
  avoiding a second, independently-drifting copy of account state. This is a reasoned deviation,
  not a silent override, but was never separately ratified against the backlog's literal text.
  Affects: [03-student-management.md](specifications/03-student-management.md).
  Source: `docs/plans/MVP-006 Student Management.md` §8.1, §21 item 4.
- **Teacher roster — `course-management`'s teacher-course-assignment data model does not exist
  yet**, so there is no source-of-truth a roster query could filter against (distinct from the
  already-tracked bulk-import-partial-failure half of this same blocker in §10 above). Building
  it now would necessarily fake the filter or ship an unfiltered-roster fallback, both violating
  the spec's own §7 "backend-pre-filtered, never client-filtered" requirement in spirit —
  deferred explicitly rather than stopgapped.
  Affects: [03-student-management.md](specifications/03-student-management.md), [04-teacher-management.md](specifications/04-teacher-management.md), [05-course-management.md](specifications/05-course-management.md).
  Source: `docs/plans/MVP-006 Student Management.md` §9, §15(d), §21 item 2(b).
- **No password-strength policy exists anywhere in this backend** (only Argon2 hashing config,
  no minimum-length/complexity check). Student self-registration — the first public,
  unauthenticated, credential-issuing endpoint — is exactly the surface where this matters most,
  and remains unbuilt pending this decision.
  Affects: [03-student-management.md](specifications/03-student-management.md).
  Source: `docs/plans/MVP-006 Student Management.md` §9, §15(a), §21 item 6.
- **No rate-limiting/abuse-prevention mechanism exists anywhere in this backend** (confirmed: no
  bucket4j/resilience4j-ratelimiter dependency, no rate-limit code pattern anywhere). Already
  affects `/api/v1/auth/login` and `/api/v1/tenant-registrations`, but student self-registration
  is a materially larger abuse surface (mass fake-account creation, subdomain/tenant probing at
  volume) — a cross-cutting infrastructure gap this module inherits and surfaces sharply, not
  something to solve unilaterally inside `user-management`.
  Affects: [03-student-management.md](specifications/03-student-management.md).
  Source: `docs/plans/MVP-006 Student Management.md` §9, §15(a), §21 item 6.
- **Self-registration enumeration risk at the business-logic layer, distinct from the
  tenant-resolution layer.** `TenantResolutionFilter` already structurally prevents
  tenant-existence enumeration (an unresolved subdomain and a resolved-but-ineligible tenant
  collapse into one identical response before any controller runs), but the still-unbuilt
  registration endpoint's own business logic must not reintroduce the same vector — e.g. a
  differently-shaped error on a downstream failure for "real tenant" vs. "no such tenant," or a
  timing difference in the duplicate-email check.
  Affects: [03-student-management.md](specifications/03-student-management.md).
  Source: `docs/plans/MVP-006 Student Management.md` §15(a).
- **Role-collision on create/import is unaddressed** — no document says what happens if a
  manual-create or (future) bulk-import row targets an email already associated with a
  different role (Teacher, Staff) in the same tenant.
  Affects: [03-student-management.md](specifications/03-student-management.md).
  Source: `docs/plans/MVP-006 Student Management.md` §4.2, §21 item 13.
- **Precondition gap: interaction with a suspended/trial/cancelled tenant is unaddressed.**
  `FR-TM-3` states tenant-status transitions "immediately affect login/access," but no document
  says whether self-registration, manual creation, or (future) bulk import should be blocked
  when the tenant isn't `active`.
  Affects: [03-student-management.md](specifications/03-student-management.md), [01-tenant-onboarding.md](specifications/01-tenant-onboarding.md).
  Source: `docs/plans/MVP-006 Student Management.md` §3, §21 item 11.
- **`FR-UM-3` device/communication-history phase-tag contradiction.** `FR-UM-3` tags
  device/communication history as MVP, but the domains that would populate them
  (device-authentication: `FR-IAS-3`–`FR-IAS-7`; notification delivery logs: `FR-NM-4`) are both
  tagged Phase 2 — STU-3's own backlog dependency list doesn't even name a dependency for these
  two tabs despite them being named in the module's business purpose. Should be resolved
  (descope explicitly to Phase 2, or clarify a reduced MVP version of each tab) before the
  history-composition capstone story (STU-3, not yet built) is treated as fully scoped.
  Affects: [03-student-management.md](specifications/03-student-management.md).
  Source: `docs/plans/MVP-006 Student Management.md` §4.5, §21 item 7.
- **Same-tenant cross-student enumeration AC gap in the source spec, distinct from the
  already-tracked cross-tenant case.** The spec's own §8 acceptance-criteria checklist names
  only the cross-tenant enumeration test explicitly; the same-tenant case (student A viewing/
  editing student B's profile by ID, both in the same tenant) is required by
  `.claude/rules/security.md`'s general enumeration-testing mandate but was never its own named
  AC. **Now structurally addressed in the shipped implementation** (the self-service `/me`
  endpoints take no `{id}` parameter at all, making same-tenant cross-student access
  impossible by construction, not merely permission-denied — see
  `docs/api/user-management.md`) — logged here so the spec's own AC list reflects this
  explicitly rather than relying on the implementation having happened to get it right.
  Affects: [03-student-management.md](specifications/03-student-management.md).
  Source: `docs/plans/MVP-006 Student Management.md` §5 AC 16, §21 (cross-referenced from AC 16's own text).

## 16. Course Management (MVP-008) — carried-forward limitations

Surfaced by `docs/plans/MVP-008 Course Management.md` §21 and confirmed still open by a
post-implementation module review; none of the three are this module's to resolve
unilaterally.

- **Course-Coordinator-vs-teacher-reassignment authorization gap**: `DomainArea.COURSES`
  grants Course Coordinator `CREATE_EDIT`/`APPROVE`, but teacher reassignment
  (`POST /api/v1/courses/{id}/teacher`) is Tenant-Admin-only, decided by the product owner
  during MVP-008's planning as the narrowest option (matching Staff Management's precedent
  of keeping the highest-leverage actions Institute-Owner-only). Implemented and tested;
  flagged here only so the asymmetry between this endpoint and the rest of the `COURSES`
  matrix is documented somewhere durable, not just in the plan file.
  Affects: [05-course-management.md](specifications/05-course-management.md).
- **DRAFT-course price-change audit scope**: `course_price_history` is written on every
  price change regardless of course status (DRAFT included), not only for published
  courses — a deliberate simplification (a status-conditional branch in the one
  non-bypassable write path was judged more fragile than writing unconditionally, and
  unconditional writing is a strict superset of the spec's literal "published course"
  requirement). If a future review wants price history scoped to published-only, that is a
  product decision to make explicitly, not something to silently narrow.
  Affects: [05-course-management.md](specifications/05-course-management.md).
- **`course_price_history` is not a substitute for the canonical `audit-log-management`
  audit row**: it satisfies the spec's literal "one audit entry with before/after" text
  today, but it is a domain-local table, not the platform's compliance-grade audit log,
  which doesn't exist yet. `CoursePriceChangedEvent` is published in the same transaction
  so `audit-log-management` can persist its own canonical row from that event once built,
  with zero rework to `course-management`. Do not report MVP-008's audit requirement as
  "fully met" without this qualification until `audit-log-management` actually exists and
  consumes the event.
  Affects: [05-course-management.md](specifications/05-course-management.md),
  [13-audit-logs.md](specifications/13-audit-logs.md).

## 17. Order and Payment Foundation (MVP-010) — carried-forward decisions

Named by `docs/plans/MVP-010 Order and Payment Foundation.md` §19 as items this module's
own documentation pass must append here; logged retroactively after a full
six-specialist review of the completed module found this file had never been updated.

- **Minimal `enrollment-management` activation slice pulled into MVP-010's own PR,
  ahead of Module 12.** PAY-2's atomic payment-confirm-and-activate acceptance criterion
  is structurally untestable without a real, callable activation `api`, so the minimal
  slice (schema + `EnrollmentActivationApi`/`EnrollmentActivationService`, no
  student-facing read endpoint, no expiry/reactivation) was built here rather than
  deferred to a separate Module 12 PR. Rationale, consequences, and the required
  Module-12-owner sign-off are recorded in
  `docs/adr/ADR-010-ledger-entry-type-and-enrollment-slice.md` (status: Proposed, not
  yet formally accepted).
  Affects: Module 12 (`enrollment-management`, not yet built as its own module).
  Source: plan §21 item 1.
- **`order`/`payment` carry a `currency` column with no upstream source.**
  `course.price` has no currency column anywhere in this codebase (a single implicit
  platform-wide currency is assumed at MVP); `order.currency`/`payment.currency` exist
  only because the backlog names them, resolved via a hardcoded
  `OrderService.DEFAULT_CURRENCY = "USD"` constant, not a ratified business decision or
  a per-tenant/per-course config value. Needs a real decision (single global currency
  vs. per-tenant vs. per-course) whenever multi-currency support is actually prioritized
  — do not silently narrow or expand this without one.
  Affects: `05-course-management.md`, this module's own (not-yet-written) spec file.
  Source: plan §21 item 7.
- **`payment.status = 'REFUNDED'` vs. terminal-row immutability — resolved.** The
  plan's draft flagged an apparent contradiction (writing `REFUNDED` onto an
  already-`CONFIRMED` row would be a second `UPDATE` on a terminal row, forbidden by
  `.claude/rules/payments.md` §1). Resolution, implemented and verified: `REFUNDED` is
  never written by any code path — a refund's existence is signaled exclusively by a
  `REFUND`-type `ledger_entry`, never by `payment.status`. See
  `docs/api/payment-management.md`'s "Refund model" section.
  Source: plan §21 item 8.
- **Approver precedence for refunds and manual payment slips — still open.** Both
  Finance Staff and Institute Owner (Tenant Admin) hold `A` on `PAYMENTS_SLIPS`; no
  document resolves precedence or dual-role interaction when both are eligible to act
  on the same refund or slip. Not a defect in what's shipped (either role may
  independently approve; there is no scenario today where they conflict, and slip
  approval is a simple first-reviewer-to-acquire-the-row-lock outcome with no implicit
  precedence assumed anywhere in code), but the product question of whether one should
  be able to override/reverse the other's decision, or whether a second layer of
  approval should ever be required, is unaddressed.
  Affects: this module's own (not-yet-written) spec file. Module 11 (manual payment
  slips) has now shipped (MVP-011) with this question deliberately left open, exactly
  as flagged here — it faced, and did not resolve, the identical question.
  Source: plan §21 item 12; MVP-011 plan §21 item 1.
- **`audit-log-management` central scoping — MVP-011's minimal slice now extended by
  MVP-019's backend and frontend (AUDIT-2/AUDIT-3); retention policy still open.**
  MVP-011 pulled forward a minimal `com.lms.auditlogmanagement` domain (a real
  `audit_log` table + a narrow `AuditLogApi.record(...)` write contract, no read/query
  surface, no consumption of other domains' pending events) per
  `docs/adr/ADR-012-audit-log-slice-and-slip-enrollment-activation.md`. MVP-019 now
  adds, on both backend and frontend: (AUDIT-2) an `AuditLogEventListener` consuming
  `CoursePriceChangedEvent`/`MaterialDeletedEvent`/`PaymentRefundedEvent` — 3 of the 5
  canonical mandatory-audit actions still lacking a consumer at MVP-011 time — (AUDIT-3)
  a tenant-scoped, filterable, paginated read endpoint (`GET /api/v1/audit-log`, see
  `docs/api/audit-log-management.md`), interim-restricted to Institute Owner/Read-only
  Auditor per the "own-area" entry above, and the tenant-admin Audit Log Viewer frontend
  (`frontend/src/app/(tenant-admin)/tenant-admin/audit-log/page.tsx`) that consumes it,
  independently enforcing the same allowlist as UX-only gating. **Still open:**
  retention/purge policy (none exists; rows retained indefinitely by default), and the
  payment-gateway-webhook-actor gap tracked separately above.
  Source: MVP-011 plan §21 item 2; ADR-012; `docs/plans/MVP-019 Audit Logs.md`.
- **`ledger_entry.entry_type` for manual-slip approval — resolved: declined.** The
  product owner explicitly declined adding a new `ledger_entry.entry_type` value (e.g.
  `SLIP_APPROVED`) for the manual-slip approval path; an approved slip's enrollment
  state is read directly from `payment_slip.status`, never merged into the ledger. This
  means a slip-approved enrollment has no corresponding ledger entry and is invisible
  on both the Payment History and Payment Dashboard screens (both are 100%
  `ledger_entry`-derived) — a real, currently-accepted product gap, not an oversight.
  Source: MVP-011 plan §17, §21 item 3; ADR-012's "Declined, for the avoidance of doubt"
  section.
- **Order-abandonment / no-cleanup state — still open.** No document anywhere defines
  what happens to an `Order` that stays `PLACED`/`PENDING` indefinitely (a gateway
  session expires, or a webhook never arrives). `order.status`'s CHECK constraint is
  deliberately incomplete (no `CANCELLED`/`EXPIRED` value) — this is not an oversight in
  the shipped schema, it's the literal absence of a policy decision to encode. A stale
  `PLACED` order today simply persists forever with no cleanup job, no visible
  student-facing "expired" state, and no reactivation path distinct from placing a new
  order.
  Affects: this module's own (not-yet-written) spec file.
  Source: plan §21 item 13.

## 18. Enrollment and Course Access (MVP-012) — carried-forward decisions

Named by `docs/plans/MVP-012 Enrollment and Course Access.md` §19/§21 as items this module's
own documentation pass must append here, per this log's established §15/§16/§17 convention. The
two genuinely new *structural* decisions this module required (the lineage-row domain model, and
the `OrderService` reactivation order-creation gate) were resolved with explicit sign-off via
`docs/adr/ADR-013-enrollment-lineage-and-reactivation-order-gate.md` — they are not open
decisions and are not repeated here. Everything below is an unresolved product/business
question, carried forward unchanged from §8 or newly surfaced by this module's own
implementation.

- **Grace period length(s) — still open, unchanged from §8.** This MVP implements a hard
  cutover at `access_expires_at` with no grace period at all — not "grace period = 0 days" as a
  ratified value, simply "no grace period feature exists yet".
  Affects: [18-smart-expiry.md](specifications/18-smart-expiry.md).
  Source: plan §21 item 1.
- **Expiry-rules-engine precedence order — still open, unchanged from §8.** Not built at all in
  this MVP; only `course.access_duration_days` is read at (re)activation time, no
  student/course/tenant/plan override layer exists.
  Source: plan §21 item 2.
- **Prorated/partial reactivation payment — still open, unchanged from §8.** This MVP always
  requires a full new order at the course's current price; no partial-payment mechanism exists
  anywhere in `OrderService`/`EnrollmentActivationService`.
  Source: plan §21 item 3.
- **Bulk expiry extension second-approver step — moot for this MVP**, since bulk extension
  itself is out of scope: no admin action exists anywhere in this module to extend an
  individual or bulk set of enrollments without a new payment.
  Source: plan §21 item 4.
- **Exact reminder timing before expiry — moot for this MVP**; no reminder notification exists
  (requires `notification-management` event wiring — Phase 2).
  Source: plan §21 item 5.
- **Whether Finance Staff (in addition to Tenant Admin) should be able to approve reactivation
  requests — newly surfaced by this module, not previously tracked here.** This module's
  implementation deferred to the already-shipped RBAC matrix (`DomainArea.ACCESS_EXPIRY`/
  `APPROVE` held only by Tenant Admin) rather than deciding this independently — three separate
  source documents (`docs/architecture/enrollment-access.md` §9, `18-smart-expiry.md`,
  `user-roles-and-permissions.md` Open Q2) still list this as unresolved, and the RBAC matrix's
  shipped state does not itself claim to have resolved it. If the actual product intent is
  "Finance Staff should also be able to approve," that is a change to the shipped RBAC matrix
  (a different, already-existing module) and must go through its own change process.
  Affects: [09-enrollments.md](specifications/09-enrollments.md),
  [18-smart-expiry.md](specifications/18-smart-expiry.md),
  `docs/requirements/user-roles-and-permissions.md` Open Q2.
  Source: plan §2, §21 item 6.
- **Whether reactivation approval should ever be tenant-configurable — newly surfaced by this
  module, not previously tracked here.** This MVP makes approval unconditionally required for
  every tenant; no config knob exists to let a tenant skip approval entirely.
  Source: plan §21 item 7.
- **Wiring `content-management`/`video-access-management` to the new `EnrollmentAccessApi` —
  still open, tracked here for visibility.** This module exposes the read-only `api`
  (`EnrollmentAccessApi.resolveAccessState`) those modules need to switch from their current
  interim, non-enrollment-based access checks (per `module-catalog.md`), but does not itself
  perform that switch — each module's own future PR must do so deliberately, not assume it
  happens automatically.
  Source: plan §21 item 10.

## 19. Tenant Admin Dashboard (MVP-015) — carried-forward decisions

Named by `docs/plans/MVP-015 Tenant Admin Dashboard.md` §19/§21 as items this module's own
documentation pass must append here, per this log's established §15/§16/§17/§18 convention.

- **No ledger-derived currency/revenue-total read endpoint exists — newly surfaced by this
  module.** The Overview's "Payments Recorded" tile is an entry count
  (`GET /api/v1/ledger/dashboard`'s `totalElements`), not a currency sum — no
  `GET /api/v1/ledger/summary`-shaped endpoint (or equivalent) has been built. Building one
  requires a new `docs/api` entry, which the issue's own text said not to add for this module;
  that tension is unresolved, not decided here.
  Affects: a future Tenant Admin Overview enhancement; `ledger-settlement-management`'s own
  scope decision if/when this is prioritized.
  Source: plan Grounding note, §6, §21 item 1.
- **No tenant-profile read endpoint exists (TEN-1) — newly surfaced by this module.** No
  `GET /api/v1/tenants/me` or equivalent exists, so a tenant name/plan/status KPI tile cannot be
  built without a new endpoint (same "no new docs/api entries" tension as above).
  Affects: `tenant-management`'s own future scope decision.
  Source: plan Grounding note, §6, §21 item 1.
- **Whether "Payments Recorded" (an entry count, not a currency figure) is legible enough as a
  KPI label — still open.** A UX wording/framing judgment call, not resolved by this module's
  implementation.
  Source: plan §21 item 2.
- **Whether "Total Teachers" belongs on this Overview — still open.** Data is available
  (`GET /api/v1/teachers`) but `TCH-1` was never in the issue's own TADASH-1 dependency list;
  this module deliberately did not add it, to avoid inventing scope.
  Source: plan Grounding note, §21 item 3.
- **`courseKeys.list()`'s params-blindness (`lib/api/courses.ts`) — still open, worked around
  locally.** This module's `useTenantCourseCounts()` hook (`lib/api/tenant-overview.ts`) uses
  its own separately-keyed queries rather than fixing the shared hook's cache-key gap — a
  future frontend-hygiene pass may want to fix `courseKeys.list()` itself.
  Source: plan Grounding note item 4, §21 item 4.
- **Whether the per-card independent-`QueryStateBoundary` pattern (this module's dashboard
  page) is the right long-term shape for a multi-domain dashboard, vs. a shared "parallel
  queries" boundary helper — still open.** This module ships the narrower, page-local
  implementation since it's the first to need this; a second multi-domain dashboard (Platform
  Admin's own future overview) may prompt extracting a shared helper.
  Source: plan §21 item 5.
- **The KPI grid DOES have per-role variation after all — corrected post-review, this file's own
  §2 claim was factually wrong.** The plan's §2 stated "every role that reaches
  `/tenant-admin/dashboard` sees the identical, tenant-scoped numbers," but that claim never
  verified `GET /api/v1/ledger/dashboard`'s actual permission grant
  (`PAYMENTS_SLIPS`/`VIEW` — Tenant Admin, Finance Staff, Student Support, Read-only Auditor
  only). Course Coordinator, Content Manager, Exam Manager, and Attendance Operator were getting
  a real, guaranteed 403 on the Payments card every dashboard load. Fixed by gating the
  Payments card's read and rendering behind `canViewPaymentDashboard(role)`
  (`lib/auth/permissions.ts`), the same pure-UX-visibility pattern already used for the
  "Teachers" nav item — backend enforcement is unchanged. Those four roles now see a 2-card grid
  (Students, Courses only); the other four see all 3 cards (adds Payments). This is a bug-fix
  correcting the implementation to match the endpoint's real permission grant, not a new
  business decision.
  Affects: this module's own implementation (`app/(tenant-admin)/tenant-admin/dashboard/page.tsx`).
  Source: post-ship review finding H1.
- **RESOLVED — the plan's own §18 "combined two-tenant shape" backend integration-test
  requirement has been added.** Originally deferred: §18 asked for one seeded Testcontainers
  fixture proving Tenant A's *composed* Overview counts (students + courses + ledger entries,
  together) exclude Tenant B's rows, added to whichever domain's existing test class is the
  natural home. This is now
  `PaymentCrossTenantIntegrationTest#tenantAdminOverviewComposedStudentCourseAndLedgerCountsNeverIncludeAnotherTenantsRows`
  (chosen as the natural home since that class already builds the richest single-call fixture
  spanning all three domains — tenant + admin + teacher + student + course + order + confirmed
  payment/ledger entry — via its existing `seedTenantWithConfirmedPayment` helper). The test seeds
  two tenants, gives Tenant A a distinguishably larger footprint (2 API-created students, 2
  published courses) than Tenant B (1 of each plus its 1 ledger entry), then asserts Tenant B's
  admin composed reads (`GET /api/v1/students`, `GET /api/v1/courses?size=1`, `GET
  /api/v1/courses?status=PUBLIC&size=1`, `GET /api/v1/ledger/dashboard`) reflect only Tenant B's
  own rows, with a same-shape sanity check on Tenant A's larger counts. All 9 tests in the class
  (75 combined with `StudentManagementIntegrationTest`/`CourseManagementIntegrationTest`) pass.
  Original deferral rationale: this module made zero backend changes (§9) and the initial
  implementation/review rounds were frontend-only in scope, so adding a new backend test was
  treated as a small, separate follow-up rather than blocking the frontend module — that follow-up
  is what this entry now records as done.
  Affects: backend test suite only (`backend/src/test/java/com/lms/paymentmanagement/
  PaymentCrossTenantIntegrationTest.java`), no application code change.
  Source: post-ship review (solution-architect) flagged the gap per plan §18; closed in a
  follow-up session per explicit user request ("add missing mandatory cross-tenant isolation
  test").

## 20. Attendance (MVP-016) — carried-forward decisions

Named by `docs/plans/MVP-016 Attendance.md` §21 as items this module's own documentation pass
must append here, per this log's established §15-§19 convention.

- **Two structural decisions confirmed, not left open** — session-equivalent scope =
  `course_lesson.id` (no new `class_session` table), and re-marking a student for the same
  session is an in-place upsert (never a `409` reject-on-duplicate). Both were explicitly put to
  the product owner during planning; recorded in full in
  `docs/requirements/specifications/10-attendance.md`'s "Resolved during MVP-016 planning"
  section, not repeated here.
- **Recurring-session ambiguity — still open, accepted as an MVP limitation.** A `course_lesson`
  reused across multiple real calendar occurrences (e.g. a weekly class attached to one lesson)
  cannot be distinguished by this schema — each week's marking overwrites the prior week's row.
  If this proves unworkable in practice, the fix is a schema migration adding an explicit
  occurrence/date discriminator, not a service-layer workaround.
  Source: plan §21.
- **Historical-roster accuracy gap — still open.** `EnrollmentAccessApi
  .listCurrentlyEnrolledStudentIds` is computed live; there is no "was this student enrolled on
  date X" query, so a report re-run after a student unenrolls omits them even for a past date
  they attended. A genuine gap in the currently available API surface, not a deliberate design
  choice.
  Source: plan §21.
- **Correction-with-history — deliberately not built.** The upsert-in-place re-mark design
  overwrites the prior status with no `previous_status`/`changed_at` trail. No audit requirement
  was specified for attendance marking (independently re-verified against
  `.claude/rules/security.md`'s mandatory-audit-action list during post-ship review — attendance
  marking is not on that list), so none is proposed. If an audit trail on corrections is later
  wanted, that is an additive `attendance_change_log` table, not a change to the existing schema.
  Source: plan §16/§21; confirmed by post-ship security review.
- **Undisclosed `course-management` API addition, remediated post-ship.**
  `CourseLookupApi.getTeacherIdsByCourseId(Set<UUID>)` was added to `course-management`'s `api`
  package during this module's post-review hardening (an N+1 fix for the Teacher report path),
  contradicting the plan's own explicit §9 claim that "no new method needed" existed for
  course-management. A post-ship review (solution-architect) flagged this as scope creep against
  a change-controlled "approved API contract" with no visible sign-off process, distinct from the
  disclosed, reviewed `enrollment-management` addition below. Remediated by recording the
  addition here and in a dated addendum to `docs/plans/MVP-016 Attendance.md` §9/§21, and by
  documenting the method's contract in `docs/api/attendance-management.md`'s "Cross-module
  contract" section and `docs/architecture/modular-monolith.md` §4's worked example — the
  method itself was independently verified safe (tenant-scoped, additive, no existing signature
  changed) by both the solution-architect and security-reviewer passes.
  Source: post-ship review (solution-architect) finding; closed in a follow-up session per
  explicit user request ("fix two High findings in process/governance gates").
- **`EnrollmentAccessApi.listCurrentlyEnrolledStudentIds(UUID)` — disclosed, reviewed addition.**
  Unlike the `course-management` addition above, this one was named in the plan's own §9 item 2
  and its own §20 implementation-order step 1 ("get this reviewed/merged first since it's a
  change to another domain's approved contract") — recorded here only for completeness alongside
  the undisclosed addition, not because it was itself a process gap.
  Source: plan §9/§20.

## 21. Exams (MVP-017) — carried-forward decisions

- **Marking-queue "assigned courses" scoping applies only to Teacher, not to Exam
  Manager/Tenant Admin** — confirmed as intended (mirrors `MVP-016 Attendance.md` §2's identical
  disambiguation for Attendance Operator vs. Teacher). `MarkingQueueService` deliberately does
  not reuse `ExamAccessGuard` for this reason; see `docs/api/exam-management.md`'s "Authorization
  model" section.
  Source: plan §21 item 2.
- **Teacher Assistant question/exam authoring is tenant-wide, not course-scoped — shipped as
  designed, PROVISIONAL/unratified per `user-roles-and-permissions.md` §3.** No TA-to-course
  assignment table exists in this codebase; a TA can author/edit any course's questions and
  `DRAFT` exams tenant-wide but can never transition past `DRAFT` (schedule/publish are both
  unconditionally denied). Confirm before this becomes a stable business rule, or build a
  TA-to-course assignment table if tighter scoping is later required.
  Source: plan §7 boxed note/§21 item 1.
- **Sequential re-attempts are not blocked at MVP** — only simultaneous duplicate/concurrent
  `IN_PROGRESS` attempts are blocked, via a partial unique index. A student who revisits the Exam
  Taking screen after already submitting (while the window is still open) silently starts a new
  attempt with no "already submitted" warning, since the backend has no signal to distinguish
  that case from a first attempt. Attempt-count limiting is Phase 2 (FR-EX-4) — flagged so a
  future reviewer doesn't mistake this for an oversight.
  Source: plan §6/§21 item 3.
- **MCQ score recomputation after a question's correct-answer flags are edited post-submission —
  still unresolved, no default assumed.** The schema does not prevent editing an MCQ question's
  options after live attempts exist against it (beyond the post-review `QuestionInUseException`
  fix, which only blocks the *options-replacing* edit path — see below); whether a later
  recompute should use the answer key's value at submission time or its current value needs
  explicit product/solution-architect sign-off before being relied on.
  Source: plan §21 item 4.
- **Whether exam-result publication requires a mandatory audit-log entry — still undecided, no
  default assumed.** `ResultsPublishingService` raises `ExamResultPublishedEvent` in-process
  (no consumer yet) specifically so `audit-log-management` can additively subscribe later with
  zero schema change if the decision resolves to "yes" — the audit-write path itself was
  deliberately not built pending that sign-off.
  Source: plan §16/§21 item 8.
- **Model Paper Library ownership (Teacher vs. Tenant Admin) — Phase 3, not resolved here, does
  not block this module.**
  Source: plan §21 item 9; also corrected in `docs/ui-ux/screen-map.md`.
- **Grading-integrity fix, shipped: `QuestionBankService.updateQuestion` rejects an
  options-replacing edit once a question is linked to any non-`DRAFT` exam or has any
  `exam_answer` row** (409 `QUESTION_IN_USE`) — found by database-architect review during initial
  implementation; a student's previously-correct answer could otherwise be silently invalidated
  with no error, since `exam_answer.response` stores selected option ids as free text with no FK
  by design.
  Source: plan §22 addendum item 4.
- **Grading-integrity gap, remediated post-ship: manual marking score had no upper bound.** A
  multi-agent review after initial ship found `MarkAnswerRequest`/`exam_answer`'s schema/service
  layer accepted an arbitrarily large `manualScore` for a single structured answer, violating
  `.claude/rules/security.md`'s "range-validated against the question's configured max points"
  requirement (plan §15). Since this schema has no per-question "max points" concept (every
  question is worth a fixed one point, `ResultsPublishingService.POINTS_PER_QUESTION`),
  remediated by capping `manualScore` at `1.00` — `MarkAnswerRequest`'s `@DecimalMax` (400) plus
  a DB `CHECK` backstop (`ck_exam_answer_manual_score_at_most_one_point`, migration V27). If a
  genuine per-question point-value concept is wanted later, that requires a schema change
  (a `max_points` column) and explicit product sign-off, not a silent reinterpretation of this
  fixed-one-point model.
  Source: post-ship multi-agent review finding, remediated same session per explicit user
  request ("fix all findings").
- **API gap, remediated post-ship: no "list exams" endpoint existed.** Initial ship exposed only
  `GET /exams/{examId}` (single, by id) and `GET /exams/my/upcoming` (Student-only) — leaving the
  Teacher Marking Queue, Teacher Results Publishing (on revisit), and Tenant Admin Exam Oversight
  screens with no way to browse to an exam whose id wasn't already known from a just-completed
  action. The frontend shipped an honest, disclosed ID-paste workaround rather than fabricating a
  list. Remediated post-ship by adding `GET /exams/courses/{courseId}/exams` (course-scoped,
  every status) and `GET /exams` (tenant-wide, staff-only, optional `status` filter) — both
  additive, within-module reads requiring no schema change; see `docs/api/exam-management.md`'s
  "Change log". The frontend was rebuilt onto these endpoints (`ExamPicker` component, Tenant
  Admin Oversight as a real paginated `DataTable`), and `ExamLookupForm`/`examLookupSchema` were
  deleted as dead code.
  Source: post-ship multi-agent review finding, remediated same session per explicit user
  request ("fix all findings").
- **Gap, remediated post-ship: no way for a student to rediscover their own past attempts across
  devices/sessions.** The frontend's `lib/exam-attempt-storage.ts` `localStorage` convenience was
  the only mechanism, and it explicitly does not survive a cleared browser or a different
  device. Remediated by adding `GET /exams/attempts/my` (the calling student's own attempt
  history, most recent first, including `CLOSED`-exam attempts that `/my/upcoming` never
  returns) — the Student Results & Review screen now tries this real backend lookup before
  falling back to `localStorage` as a same-browser fast path only.
  Source: post-ship multi-agent review finding, remediated same session per explicit user
  request ("fix all findings").
- **UX gap, remediated post-ship: cross-tenant/cross-student exam and attempt ids fell through
  to the generic retryable `ErrorState` instead of a dedicated not-found state.** Inconsistent
  with this codebase's own established convention elsewhere (e.g. the Tenant Admin teacher-detail
  page's "Teacher not found" pattern) and misleading (offering "Try again" on a permanently
  nonexistent/not-yours resource). Remediated by special-casing a 404 on the Student Exam Taking
  and Results & Review pages into a dedicated not-found `EmptyState` with a "Back to Exams"
  action and no retry control.
  Source: post-ship multi-agent review finding, remediated same session per explicit user
  request ("fix all findings").
- **Root cause found and fixed: the Exam Taking screen's attempt-start request could hang
  indefinitely in local development.** Confirmed via a live debug session: firing `useMutation`'s
  `mutate()` from a mount `useEffect` resolves the underlying network request correctly, but
  under React's default `reactStrictMode: true` in `next dev` (Turbopack), the mutation observer
  never notified the component of the result — `isPending` stayed `true` forever even though the
  request had already succeeded. This is a dev-only artifact (StrictMode's double-render/
  double-effect behavior is stripped from production builds, so it never manifested against
  `next build`/`next start`), but it broke local development and any Playwright run against the
  local dev server. Fixed by converting `useStartAttempt` from a `useMutation` fired on mount to
  a `useQuery` (the operation is idempotent — "starts OR RESUMES" the single `IN_PROGRESS`
  attempt, backed by a partial unique index — matching TanStack Query's own guidance to use
  `useQuery`, not `useMutation`, for automatic/mount-triggered fetches).
  Source: post-ship multi-agent review finding (reported as a reproducible E2E-suite failure),
  root-caused and fixed same session per explicit user request ("fix all findings").

## 22. Email Notifications (MVP-018) — carried-forward decisions

- **Which staff sub-role(s) may manage `notification_template` rows, or trigger sends manually —
  still unresolved, no default assumed.** Unspecified anywhere in the source requirements
  (`12-notifications.md` §11); this MVP ships no authoring endpoint/UI at all (see the
  template-origination item below), so the question of who would be authorized to use one remains
  open until a future module adds authoring.
  Source: plan §21 item 1 (issue's own explicit open decision).
- **MVP-level failure handling for a failed email send is undefined by design — no retry/backoff
  was implemented, and none should be assumed.** A `FAILED` `notification_outbox` row is terminal;
  the issue itself explicitly instructed against silently implementing a retry mechanism. If a
  retry/backoff policy is wanted later, it needs its own product decision and schema
  consideration (this table has no attempt-count/next-retry-at column today).
  Source: plan §9.2/§13/§21 item 1 (issue's own explicit open decision).
- **Template-origination gap — resolved for newly-registered tenants only, not backfilled for
  tenants that existed before this module shipped.** No staff role/UI can author a
  `notification_template` row in this MVP. Decision made (outside the plan document, confirmed
  directly with the requester before implementation): `TenantRegistrationService.register()` — the
  only production code path in this codebase that actually creates a `tenant` row today (there is
  no tenant-approval endpoint wired to anything real yet, so registration is the only available
  hook) — now publishes `tenantmanagement.api.TenantRegisteredEvent`, which
  `notificationmanagement.service.NotificationTemplateSeedingService` consumes
  (`@TransactionalEventListener(phase = AFTER_COMMIT)`) to seed three default, per-tenant
  `notification_template` rows (`PAYMENT_CONFIRMED`/`PAYMENT_REJECTED`/`PAYMENT_REFUNDED`) with
  fixed platform-default copy. This satisfies "tenant-owned, never a shared runtime default" for
  every tenant registered from this point forward. **It does not backfill tenants registered
  before this feature shipped** — no data migration was written for this (a raw-SQL seed would
  have deviated from this codebase's app-generated-UUIDv7 convention, and it was not part of the
  confirmed scope) — those tenants' dispatch attempts will honestly fail closed (`FAILED` rows)
  until either a future authoring/seeding pass backfills them, or an operator manually inserts
  their three rows. Not a bug; a disclosed, accepted gap matching this module's own "a tenant with
  zero template rows simply gets FAILED dispatch rows, which is a real, testable, honest failure
  mode" framing.
  Source: plan §21 item 1 (option (a) chosen); confirmed directly with the requester
  (2026-09-07) before implementation began.
- **`RefundService`/`StudentOrder` scope addition — confirmed and implemented.** Populating
  `PaymentRefundedEvent.studentId` required a new read-only `StudentOrderRepository.findById`
  lookup inside `RefundService.processRefund` (`Payment` itself has no `studentId` field). Confirmed
  directly with the requester before implementation (2026-09-07); implemented, then relocated
  during payment-ledger-specialist review to run immediately after the existing pessimistic lock
  and before the `payment_refund`/`ledger_entry` writes, so a missing order fails fast rather than
  aborting an already-attempted write via transaction rollback. No ledger/refund/locking semantics
  changed; `payment.status` remains untouched by this service, as before.
  Source: plan §21 item 2; payment-ledger-specialist review (2026-09-07).
- **`12-notifications.md` internal documentation inconsistency on "result published" — not
  resolved here, flagged for a future doc-reconciliation pass.** That doc's own §4/§8 name "result
  published" as an MVP-scope trigger example with no phase qualifier, while its §10 correctly
  cites `functional-requirements.md` FR-NM-5 placing it in Phase 2. This implementation follows
  the authoritative phase table, not the inconsistent narrative text, and does not wire
  `ExamResultPublishedEvent` — no code change resolves the documentation contradiction itself.
  Source: plan §6/§21 item 3.
- **Async-thread `TenantContextHolder` discipline is precedent-setting for this codebase.** This is
  the first shipped production code path (`NotificationOutboxService`,
  `NotificationTemplateSeedingService`, `NotificationDispatchService`) to manually manage
  `TenantContextHolder` across a real thread/timing boundary (`@TransactionalEventListener(phase =
  AFTER_COMMIT)` and the `@Scheduled` dispatch poller) — the set-in-try/clear-in-finally pattern,
  keyed off the event/row's own `tenantId` field rather than ambient context, is now the reference
  precedent for any future domain needing to cross a similar boundary. A dedicated security review
  pass confirmed the pattern is sound across all four call sites (2026-09-07) — see
  `docs/architecture/modular-monolith.md`'s notification-management worked example once written.
  Source: plan §14/§21 item 4.
- **RESOLVED — `NotificationDispatchService.dispatchOne` no longer holds a DB transaction (or its
  `FOR UPDATE SKIP LOCKED` row lock) open across the blocking `MessagingProviderApi.sendEmail`
  call.** The original design (below, superseded) was a disclosed, deliberate exception to
  `.claude/rules/backend.md`'s "do not span a transaction across an outbound call" rule, reviewed
  and accepted 2026-09-07 as an MVP tradeoff. A subsequent multi-agent review (security-reviewer,
  database-architect, solution-architect) re-flagged it — database-architect as High,
  solution-architect as Critical — as a real duplicate-send risk (a later statement failing after
  the email had already sent would roll back the `SENT` transition, leaving the row `PENDING`
  again for the next poll to re-send) and an availability risk with no SMTP timeouts configured.
  Fixed same session per explicit user request ("fix all findings"): V28 gained a `SENDING`
  claimed-state (`PENDING -> SENDING -> SENT|FAILED`), and dispatch is now three phases across two
  new collaborator beans — `NotificationDispatchClaimService#claim` commits the `PENDING ->
  SENDING` transition (and releases the claim lock) in its own short transaction BEFORE any SMTP
  call; the SMTP call itself runs with no open transaction; `NotificationDispatchFinalizeService`
  commits the terminal status (+ `in_app_notification` insert on success) afterward in a final
  short transaction. The "two concurrent dispatch attempts never both send" guarantee is preserved
  (only one caller ever wins the claim). Residual, disclosed, bounded gap: a crash between the
  claim committing and finalize committing leaves a row stuck at `SENDING` with no automatic
  recovery — no retry policy exists for this module at all (already an accepted decision, see
  below) — but that window is now bounded by the SMTP timeouts added in the same fix (previously
  unbounded) and is far narrower than the previous design's exposure (the entire SMTP call).
  Original source: security-reviewer finding (2026-09-07), design per plan §9.2. Fix source:
  post-ship multi-agent review finding, resolved same session per explicit user request ("fix all
  findings").
- **RESOLVED — the residual "stuck at `SENDING` with no automatic recovery" gap noted immediately
  above is now closed.** V29 (additive, does not edit V28) adds `claimed_at` to
  `notification_outbox`, written by `NotificationDispatchClaimService#claim` in the same
  transaction as the `PENDING -> SENDING` write. `NotificationDispatchReconciliationService`, wired
  into `NotificationDispatchPoller` as its own, less-frequent `@Scheduled` method
  (`reconcileStuckSendingRows`), finds any `SENDING` row whose `claimed_at` is older than a
  timeout constant (2 minutes — an implementation-time tuning constant set well above this
  module's configured SMTP connect/read/write timeouts, not a ratified SLA) and marks it `FAILED`.
  This is failing a stuck claim forward, not a retry: the row never re-enters `PENDING` and no send
  is re-attempted, so the module's "no automatic retry" decision (below) is unaffected. A row
  claimed within the timeout window is left alone, so a genuinely in-flight dispatch is never
  falsely failed.
  Source: post-ship multi-agent review finding, resolved same session per explicit user request
  ("fix all findings").
- **SMTP relay: Gmail/Google Workspace SMTP, confirmed for this MVP.** `integration-architecture.md`
  §8's "Email/SMTP provider — not selected" open question, and the plan's own explicit "this plan
  does not resolve it" line, both predate this decision. Confirmed directly with the requester in
  conversation ("No production SMTP relay/vendor - Let's configure google smtp for sending
  emails.") before `application.yml` was written to default `MAIL_HOST` to `smtp.gmail.com`. Not
  independently re-litigated by the later multi-agent review that flagged this as an
  "undocumented decision" (architecture finding, High) — that finding is addressed by this entry
  existing, not by reverting the config. Known, accepted operational limitation: consumer
  Gmail/Workspace SMTP enforces per-account daily send caps (roughly 500/day on a plain Gmail
  account, ~2000/day on Workspace) and is not a dedicated transactional-email provider — acceptable
  for MVP/low-volume traffic, but worth revisiting via a real vendor decision (`MAIL_HOST`/
  `MAIL_PORT` are already externalized via env vars for a no-code-change swap later) before this
  platform's notification volume approaches those caps.
  Source: user decision (prior session, 2026-09-08); architecture-reviewer finding (this session)
  addressed by documenting the decision rather than reverting it.
- **Poll interval (5s), dispatch batch size (50), and the Notification Center's real-time-delivery
  mechanism/page size are implementation-time technical defaults, not ratified SLAs or business
  decisions.**
  Source: plan §21 item 6.
- **RESOLVED — Teacher activity-feed screen's `screen-map.md` IA gap is closed.** The Teacher
  Notification Center frontend shipped at `app/(teacher)/teacher/notifications/page.tsx`, reusing
  the Student list/mark-read/unread-count components against the same role-agnostic,
  self-scoped backend endpoints, and `docs/ui-ux/screen-map.md`'s Teacher Portal section now has
  its own "Activity Feed" line documenting it. Genuinely empty at launch by construction — no
  Teacher-triggering event exists in MVP-018's wiring (all three trigger events are payment
  outcomes, which only reach Student recipients).
  Source: plan §11/§21 item 5. Fix source: post-ship multi-agent review finding, resolved same
  session per explicit user request ("fix all findings").
- **Template seeding happens at tenant *registration*, before any tenant-approval gate exists in
  this codebase — flagged as a forward-looking risk, not a defect.**
  `NotificationTemplateSeedingService` seeds a new tenant's default `notification_template` rows
  from `TenantRegisteredEvent`, published by `TenantRegistrationService.register()` at the point a
  tenant record is created — which today is always `PENDING_APPROVAL` status, since no separate
  "approval" workflow/state-transition exists anywhere in this codebase yet
  (`TenantRegistrationService`'s own javadoc confirms there is no parameter or code path that lets
  a caller choose a different initial status). This is an accurate description of the current
  system, not a bug: a tenant's templates (and therefore its email-sending eligibility) exist from
  the moment of registration, not from some later "approved" moment, because there currently is no
  later moment. If/when a real tenant-approval workflow is built, whoever builds it must
  re-examine whether seeding-at-registration is still the intended semantics, or whether it should
  move to fire on approval instead (e.g. to avoid an unapproved/rejected tenant ever having live
  templates, if that later becomes a concern) — this is not decided here, only flagged so it isn't
  silently assumed correct forever.
  Source: post-ship multi-agent review finding (solution-architect), logged same session per
  explicit user request ("fix all findings").
  **Update (MVP-020):** a real tenant-approval workflow now exists (approve/reject of a
  `pending_approval` tenant, `docs/api/tenant-management.md`) — the "if/when" above is resolved to
  "now." Whether template seeding should move from registration-time to approval-time remains
  unre-examined; this item is left open rather than silently assumed still-correct.

## 23. Platform Admin Dashboard (MVP-020) — carried-forward decisions

Per `docs/plans/MVP-020 Platform Admin Dashboard.md` §19's own instruction to carry these
forward — none of the following is resolved by this module, only scoped out of it explicitly:

- **Suspend/cancel of an already-`active` tenant** — no endpoint exists. Carries forward
  MVP-004 §21 item 9's open question about the session-invalidation mechanism a suspend would
  need (revoking every active session for that tenant's users), still unresolved.
- **Cancellation reversibility** — whether a cancelled tenant can ever be reactivated, and by
  what mechanism, is undecided; no endpoint exists for either cancel or a hypothetical
  reactivation.
- **Rejection-reason capture** — `POST /api/v1/platform-admin/tenants/{id}/reject` takes no
  request body and records no reason; a rejected applicant currently has no structured record of
  why. Whether this needs a reason field (and whether it should be visible to the rejected
  applicant) is a product decision, not made here.
- **Revenue-total / tenant-profile KPI gaps** — no endpoint anywhere computes a platform-wide
  revenue total; the Cross-Tenant Payment Dashboard intentionally shows individual ledger rows
  only, per `.claude/rules/payments.md` §1's "ledger is the source of truth" rule (a client-side
  sum across paginated cross-tenant rows would violate that rule — see
  `docs/api/ledger-settlement-management.md`'s Platform Admin section). The Platform Admin
  Dashboard's own Overview screen remains a static placeholder with no KPI/summary data-fetching
  at all (`docs/ui-ux/screen-map.md`'s Platform Admin Portal section).
- **Tenant name/subdomain search** — `GET /api/v1/platform-admin/tenants` has no search query
  param and no supporting index; the module plan's own §8 documents this as a deliberate
  scope decision, not an oversight, but it remains a real gap for a platform with many tenants.
- **Currency on cross-tenant ledger rows** — `ledger_entry` has no `currency` column, so
  `PlatformLedgerEntryResponse.amount` renders with no unit on both payment dashboard screens.
  Surfaced during this module's own frontend review; see
  `docs/api/ledger-settlement-management.md`'s Platform Admin section for the full note.
  Resolving it requires a backend/schema change or a platform-wide implicit-currency decision,
  neither made here.
- **Plan & feature-flag editing, platform integrations config, platform analytics, support
  ticket queue, impersonation ("view as tenant")** — none of these shipped; see
  `docs/ui-ux/screen-map.md`'s Platform Admin Portal section for the full unshipped list. Any
  future impersonation capability specifically must be a visually loud, backend-issued session
  per `.claude/rules/ui-ux.md` §1 — never a locally toggled UI state — when it is eventually
  built.
- **RESOLVED — plan §21 item 6 (whether the Tenant Approval Detail screen needs the full
  persistent tenant-context banner).** Shipped as `showTenantContext={false}`: the tenant's own
  name already anchors the page as its `PageHeader` title, and the banner exists specifically to
  disambiguate "inspecting a *different* domain's data while 'in' a tenant's context" (the
  payments/audit-log drill-downs), which doesn't apply to a same-tenant detail view. See
  `docs/ui-ux/platform-admin-dashboard-conventions.md` §1's screen table for the full rationale.
  Recorded here per the plan's own instruction not to leave a flagged decision resolved only
  implicitly in a component/conventions-doc comment.
  Source: plan §21 item 6; closed same session per explicit user request ("fix all findings").
- **Test-naming clarification, not a coverage gap: `emptyPendingApprovalQueueIsDistinguishableFromFilteredToZeroResults`-style backend tests are intentionally narrower than their plan-implied name.** `PageResponse` carries no field distinguishing "true zero" from "filtered-to-zero" — that distinction is a frontend-only UX concern (both Testcontainers tests assert `200` with an empty page for either case, mirroring the actual backend contract), and the two-empty-states requirement is separately, fully covered by the frontend Playwright suites (`platform-admin-tenants.spec.ts`, `platform-admin-audit-log.spec.ts`). Recorded here so a future reviewer doesn't re-flag the backend test names as a missing scenario.
  Source: post-ship multi-agent review finding (qa-test-engineer), logged same session per
  explicit user request ("fix all findings").
- **RESOLVED — a wrong-portal-kind session (e.g. a Tenant Admin token) visiting a Platform Admin
  route redirects to `/platform-admin/login?reason=session_expired`, not a rendered
  `PermissionDeniedState`.** The module plan's own wording ("sees a permission-denied state") was
  imprecise: `RouteGuard`'s actual, tested behavior for this case is the same
  session-expired-style redirect used for an unauthenticated visitor, which still fully blocks
  access (and the backend independently, and separately, rejects the underlying API calls with
  401/403 regardless of what the frontend does) — this is a UX presentation choice, not a security
  gap. Two independent reviewers (ui-ux-reviewer, qa-test-engineer) surfaced this as only
  documented inside a Playwright test comment (`route-groups.spec.ts`,
  `shared-states.spec.ts`) rather than in `docs/ui-ux/`; recorded here per this file's own
  convention for closing a plan-vs-shipped-behavior gap.
  Source: post-ship multi-agent review finding (ui-ux-reviewer, qa-test-engineer), logged same
  session per explicit user request ("fix all findings").

## 24. Integration and Staging Review (MVP-021) — carried-forward decisions

Surfaced while building MVP-021's frontend deliverable (`docs/plans/MVP-021 Integration and
Staging Review.md` §9.3/§18.4's real-backend, two-tenant Playwright fixture layer). Both items
below are structural gaps that block **every** one of the ~15 planned cross-tenant E2E specs
identically, not a per-area gap — full evidence trail in `frontend/e2e/README.md` §4.

- **No API path exists to provision a tenant's first Tenant Admin, or any Platform Admin,
  account.** Tenant self-registration (`POST /api/v1/tenant-registrations`) only creates a
  loginless `pending_approval` row; every downstream account-creation endpoint requires an
  already-authenticated Tenant-Admin-or-higher actor that itself has no provisioning path
  (`V4__create_platform_admin_user.sql` seeds zero rows; no `CommandLineRunner`/dev-seed bean
  exists anywhere in `backend/src/main/java`; `StaffCreateRequest.roleCode` explicitly excludes
  `TENANT_ADMIN`, citing "provisioned by other flows" — no such flow exists). This is a genuine
  product/engineering decision (how is a tenant's first admin meant to be provisioned in real
  life?), not just a test-infra gap, and touches authentication/account-provisioning architecture
  — change-controlled per root `CLAUDE.md`; needs an explicit decision (and an Accepted ADR if it
  changes authentication architecture) before implementation.
  Tracked: [GitHub issue #26](https://github.com/mohanranaweera/lms-saas-platform/issues/26).
- **No CORS configuration exists on the backend**, already flagged as a caveat in
  `docs/api/identity-access-service.md`'s "CORS caveat" section and independently reproduced
  during this module's implementation: every cross-origin browser request from the natively-run
  local frontend (`localhost:3000`) to the natively-run local backend (`localhost:8080`) is
  unconditionally blocked, credentialed or not. This is a narrower, more mechanical fix (an
  explicit, origin-allowlisted CORS config scoped to local dev) than the account-provisioning item
  above, but still requires a `backend/` change outside this frontend-only task's authorization.
  Tracked: [GitHub issue #27](https://github.com/mohanranaweera/lms-saas-platform/issues/27).
- Once both are resolved, the remaining ~14 of MVP-021's planned cross-tenant Playwright specs
  (identity/session, tenant management, content/material, enrollment, payment (orders), payment
  slip, ledger/settlement, attendance, exams, notifications, audit log, teacher management,
  student management, staff management) are mechanical to add — same fixture
  (`frontend/e2e/fixtures/real-backend-session.ts`), same pattern as the one already-built
  demonstration spec (`frontend/e2e/cross-tenant/course-management.spec.ts`), different
  route/endpoint per `docs/api/*.md`. Not silently dropped — tracked as explicit follow-up work in
  `frontend/e2e/README.md` §6.
